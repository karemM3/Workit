import mongoose from 'mongoose';

// These are just placeholder models for imports to work
const Message = {};
const Conversation = {};

export { Message, Conversation };
